export interface CustomerType {
  id: number;
  typeName: string;
}
